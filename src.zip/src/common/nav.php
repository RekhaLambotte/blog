<header class="bg">
    <div>
        <a href="../../index.php"><img src="../../src/img/site/logotest.gif" alt="Logo Site Belgium Video-Gaming"></a>
    </div>
    <nav>
        <ul>
            <li><a href="../../src/pages/index.php">PS5</a></li>
            <li><a href="">PS4</a></li>
            <li><a href="">XBOX ONE</a></li>
            <li><a href="">SWITCH</a></li>
            <li><a href="">PC</a></li>
            <li><a href="">VR</a></li>
        </ul>
    </nav>
    <div>
    <nav>
        <ul>
            <li><a href="../../src/pages/login.php"><i class="fas fa-sign-in-alt"></i>Login</a></li>
            <li><a href="../../src/pages/register.php"><i class="fas fa-user-plus"></i>S'enregistrer</a></li>
        </ul>
    </nav>
    </div>
</header>