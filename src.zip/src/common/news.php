<section id="news">
    <h2 class="mb-2 ml-9">dernières news...</h2>
    <div class="contenuNews">
        <div class="vignette v1">
            <p class="newsCategorie ml-2">catégorie</p>
            <h2 class="ml-2 mb-2 newsTitre">The last of us: Un remaque en préparation ?</h2>
        </div>
        <div class="miniVignette">
            <div class="vignette v2">
                <p class="newsCategorie ml-2">catégorie</p>
                <h2 class="ml-2 mb-2 newsTitre">Returnal: Le jeu est vraiment infernal </h2>
            </div>
            <div class="vignette v3">
                <p class="newsCategorie ml-2">catégorie</p>
                <h2 class="ml-2 mb-2 newsTitre">Animal Crossing: La mise à jour de juin annoncée</h2>
            </div>
        </div>
    </div>
</section>