<footer class="bg">
    <img src="../../src/img/site/logotest.gif" alt="Logo Belgium Video Gaming">
    <p>2021 &copy; <a href="https://aftercoaching.be">After Coaching</a></p>
</footer>