<?php

    $titre = "votre compte";
    require "../../src/common/template.php";
    // require "../../src/fonctions/dbFonction.php";
    // require "../../src/fonctions/mesFonctions.php";

?>

<section class="register">

</section>


<?php
    require "../../src/common/footer.php";
?>